# Student Performance Analytics Engine

**Author:** Md Adnan Ashraf  
**Language:** Python  
**Libraries:** Pandas, NumPy, Matplotlib

## Project overview
This project analyses student marks and attendance. It calculates totals, averages, percentages, grades, pass/fail results, identifies high- and low-performing students, and creates charts for quick interpretation.

The included `data/students.csv` is a **synthetic demonstration dataset**. It does not contain real student records.

## Features
- Dataset loading and validation
- Total, average and percentage calculation
- Automatic grade assignment
- Pass/fail detection (a student must score at least 40 in every subject)
- Top-five student identification
- Subject-wise average analysis
- Attendance threshold analysis (75%)
- Charts for subject averages, grade distribution, and attendance vs performance
- Export of processed results to CSV

## Project structure
```text
Student_Performance_Analytics_Md_Adnan_Ashraf/
├── data/
│   └── students.csv
├── outputs/
│   └── (generated charts and result CSV)
├── reports/
│   └── project_report.md
├── Student_Performance_Analytics.ipynb
├── student_performance.py
├── requirements.txt
└── README.md
```

## Run locally
1. Install Python 3.9 or later.
2. Open a terminal in this project folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python student_performance.py
   ```
5. Open the `outputs/` folder to view the generated CSV and charts.

## Run in Google Colab
1. Upload `Student_Performance_Analytics.ipynb` to Google Colab.
2. Upload `data/students.csv` when prompted, or upload the CSV from the `data` folder.
3. Run the notebook cells from top to bottom.

## Grade scale
| Percentage | Grade |
|---:|:---|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| 40–49.99 | E |
| Below 40 | F |

## Customisation
Replace `data/students.csv` with your own permitted dataset while retaining these columns:
`Student_ID, Student_Name, Python, Java, DBMS, Mathematics, Attendance`

Marks and attendance must be between 0 and 100. Keep student records anonymised unless you have permission to use identifiable data.

## Academic integrity and attribution
This is an independently written implementation based on the general project idea and feature list of the reference repository. It is not an exact copy of another student's files. If you used the reference repository for inspiration, acknowledge it in your submission according to your college's rules.

## Author
**Md Adnan Ashraf**
