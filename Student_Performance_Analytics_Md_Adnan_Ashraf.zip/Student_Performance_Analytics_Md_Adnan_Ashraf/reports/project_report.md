# Project Report: Student Performance Analytics Engine

**Submitted by:** Md Adnan Ashraf  
**Technology:** Python, Pandas, NumPy and Matplotlib

## 1. Introduction
The Student Performance Analytics Engine is a small data-analysis application designed to summarise student academic results. It processes marks across four subjects and attendance percentages, then presents useful indicators in tabular and graphical form.

## 2. Problem statement
Manually calculating totals, averages, grades and class-level trends for multiple students can be repetitive and error-prone. This project automates those calculations and provides visual summaries to support review of the sample dataset.

## 3. Objectives
- Read student data from a CSV file.
- Calculate each student's total, average and percentage.
- Assign grades using a defined grading scale.
- Determine pass/fail status using a minimum subject mark of 40.
- Summarise attendance and subject performance.
- Identify top-performing students and generate charts.

## 4. Tools and technologies
- **Python:** application logic.
- **Pandas:** reading, cleaning and analysing tabular data.
- **NumPy:** numerical operations and conditional classification.
- **Matplotlib:** visualisation.
- **CSV:** portable dataset format.
- **Google Colab:** optional cloud notebook environment.

## 5. Dataset description
The demonstration dataset contains 30 synthetic student records. Each record has a student ID, student name, marks in Python, Java, DBMS and Mathematics, and attendance percentage. All values are fictional and are provided only to demonstrate the program.

## 6. Methodology
1. Load the CSV dataset.
2. Check required columns, duplicate IDs and numeric ranges.
3. Calculate total marks across four subjects.
4. Calculate average and percentage.
5. Assign a grade based on the percentage.
6. Mark a student as Pass only if every subject mark is at least 40.
7. Classify attendance as satisfactory at 75% or above.
8. Export the processed table and create three charts.

## 7. Calculation formulas
- **Total marks** = Python + Java + DBMS + Mathematics
- **Average** = Total marks / 4
- **Percentage** = (Total marks / 400) × 100

## 8. Grading criteria
A+ (90–100), A (80–89.99), B (70–79.99), C (60–69.99), D (50–59.99), E (40–49.99), F (below 40).

## 9. Outputs
The program creates:
- `student_analysis_results.csv` — calculated metrics and classifications.
- `subject_averages.png` — average marks in each subject.
- `grade_distribution.png` — number of students in each grade.
- `attendance_vs_performance.png` — scatter plot comparing attendance and percentage.

## 10. Limitations
The supplied data is synthetic and small. Results should not be used to make real academic decisions. The project does not establish that attendance causes higher or lower marks. Real deployments would need privacy controls, institutional validation, larger datasets and appropriate review.

## 11. Future scope
- Add a graphical user interface.
- Support more subjects and configurable grading policies.
- Add filters by class or semester.
- Use anonymised real datasets with appropriate permission.
- Add a dashboard and downloadable PDF reports.

## 12. Conclusion
The project demonstrates how Python data-analysis libraries can automate basic academic performance calculations and visualise a dataset. It provides a foundation that can be extended with additional features and validated institutional data.
