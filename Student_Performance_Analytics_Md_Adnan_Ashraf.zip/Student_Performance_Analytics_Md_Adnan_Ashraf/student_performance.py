"""
Student Performance Analytics Engine
Author: Md Adnan Ashraf

A beginner-friendly analytics project using Pandas, NumPy and Matplotlib.
The included CSV contains synthetic sample data for demonstration only.
"""

from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

SUBJECTS = ["Python", "Java", "DBMS", "Mathematics"]
PASS_MARK = 40
ATTENDANCE_THRESHOLD = 75

def load_data(csv_path: str) -> pd.DataFrame:
    """Load and validate the student dataset."""
    data = pd.read_csv(csv_path)
    required = {"Student_ID", "Student_Name", *SUBJECTS, "Attendance"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    if data["Student_ID"].duplicated().any():
        raise ValueError("Student_ID values must be unique.")
    for col in SUBJECTS + ["Attendance"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    if data[SUBJECTS + ["Attendance"]].isna().any().any():
        raise ValueError("Marks and attendance must contain valid numeric values.")
    if not data[SUBJECTS].apply(lambda s: s.between(0, 100)).all().all():
        raise ValueError("Subject marks must be between 0 and 100.")
    if not data["Attendance"].between(0, 100).all():
        raise ValueError("Attendance must be between 0 and 100.")
    return data

def grade_from_percentage(value: float) -> str:
    if value >= 90: return "A+"
    if value >= 80: return "A"
    if value >= 70: return "B"
    if value >= 60: return "C"
    if value >= 50: return "D"
    if value >= PASS_MARK: return "E"
    return "F"

def analyse_students(data: pd.DataFrame) -> pd.DataFrame:
    """Calculate totals, averages, grades and pass/fail status."""
    result = data.copy()
    result["Total_Marks"] = result[SUBJECTS].sum(axis=1)
    result["Average_Marks"] = result[SUBJECTS].mean(axis=1).round(2)
    result["Percentage"] = (result["Total_Marks"] / (len(SUBJECTS) * 100) * 100).round(2)
    result["Grade"] = result["Percentage"].apply(grade_from_percentage)
    result["Result"] = np.where((result[SUBJECTS] >= PASS_MARK).all(axis=1), "Pass", "Fail")
    result["Attendance_Status"] = np.where(
        result["Attendance"] >= ATTENDANCE_THRESHOLD, "Satisfactory", "Below threshold"
    )
    return result

def print_summary(analysis: pd.DataFrame) -> None:
    print("\\nSTUDENT PERFORMANCE SUMMARY")
    print("=" * 72)
    print(f"Students analysed : {len(analysis)}")
    print(f"Class average     : {analysis['Percentage'].mean():.2f}%")
    print(f"Pass count        : {(analysis['Result'] == 'Pass').sum()}")
    print(f"Fail count        : {(analysis['Result'] == 'Fail').sum()}")
    print(f"Attendance average: {analysis['Attendance'].mean():.2f}%")
    print("\\nTOP 5 STUDENTS")
    print(analysis.nlargest(5, "Percentage")[
        ["Student_Name", "Percentage", "Grade", "Result"]
    ].to_string(index=False))
    print("\\nSUBJECT-WISE AVERAGE")
    print(analysis[SUBJECTS].mean().round(2).to_string())

def create_charts(analysis: pd.DataFrame, output_dir: str = "outputs") -> None:
    """Save charts for subject averages, grade distribution and attendance."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(8, 5))
    analysis[SUBJECTS].mean().plot(kind="bar")
    plt.title("Average Marks by Subject")
    plt.ylabel("Average marks (out of 100)")
    plt.xlabel("Subject")
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.savefig(out / "subject_averages.png", dpi=160)
    plt.close()

    plt.figure(figsize=(7, 5))
    analysis["Grade"].value_counts().reindex(
        ["A+", "A", "B", "C", "D", "E", "F"], fill_value=0
    ).plot(kind="bar")
    plt.title("Grade Distribution")
    plt.xlabel("Grade")
    plt.ylabel("Number of students")
    plt.tight_layout()
    plt.savefig(out / "grade_distribution.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.scatter(analysis["Attendance"], analysis["Percentage"], alpha=0.8)
    plt.title("Attendance vs Academic Percentage")
    plt.xlabel("Attendance (%)")
    plt.ylabel("Academic percentage (%)")
    plt.xlim(0, 100)
    plt.ylim(0, 100)
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(out / "attendance_vs_performance.png", dpi=160)
    plt.close()

def run(csv_path: str, output_dir: str) -> pd.DataFrame:
    data = load_data(csv_path)
    analysis = analyse_students(data)
    print_summary(analysis)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    analysis.to_csv(output / "student_analysis_results.csv", index=False)
    create_charts(analysis, output_dir)
    print(f"\\nAnalysis files saved in: {output.resolve()}")
    return analysis

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyse student academic performance.")
    parser.add_argument("--data", default="data/students.csv", help="Path to students CSV")
    parser.add_argument("--output", default="outputs", help="Folder for reports and charts")
    args = parser.parse_args()
    run(args.data, args.output)
